package com.zybooks.wgu;

import java.util.ArrayList;

public class AlertsObject {

    private final static ArrayList<AlertsObject> Alerts = new ArrayList<>();
    private final static ArrayList<AlertsObject> Alerts2 = new ArrayList<>();

    private final int alertsID;
    private final String alerts;
    private final String startDate;
    private final String endDate;

    public AlertsObject() {
        alertsID = 0;
        alerts = "alerts";
        startDate   = "date";
        endDate = "date";
    }

    public AlertsObject(int  alertsID, String alerts, String startDate , String endDate) {
        this.alertsID = alertsID;
        this.alerts = alerts;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public int getAlertsID() {
        return alertsID;
    }



    public static void addAlerts (AlertsObject alertsObject) {Alerts.add(alertsObject);}
    public static void addAlerts2 (AlertsObject alertsObject) {Alerts2.add(alertsObject);}

    public static void deleteAlerts () {Alerts.clear();}
    public static void deleteAlerts2 () {Alerts2.clear();}

    public static ArrayList<AlertsObject> getAllAlerts() {

        return Alerts;
    }

    public static ArrayList<AlertsObject> getAllAlerts2() {

        return Alerts2;
    }

    public String getAlerts() {
        return alerts;
    }

}
