package com.zybooks.wgu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import Assessments.AssessmentChoose;
import Courses.CoursesAdd;
import Courses.CoursesView;
import Terms.TermsAdd;
import Terms.TermsView;

public class HomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);

    }

    public void termsClick(View view) {
        Intent open = new Intent(this, TermsView.class);
        startActivity(open);
    }

    public void assessmentsClick(View view) {
        Intent open = new Intent(this, AssessmentChoose.class);
        startActivity(open);
    }

    public void coursesClick(View view) {
        Intent open = new Intent(this, CoursesView.class);
        startActivity(open);
    }

    public void viewnotesClick(View view) {
        Intent VIEW = new Intent(this, NotesView.class);
        startActivity(VIEW);
    }

    public void coursesAddClick(View view) {
        Intent open = new Intent(this, CoursesAdd.class);
        startActivity(open);
    }

    public void termsAddClick(View view) {
        Intent open = new Intent(this, TermsAdd.class);
        startActivity(open);
    }

}