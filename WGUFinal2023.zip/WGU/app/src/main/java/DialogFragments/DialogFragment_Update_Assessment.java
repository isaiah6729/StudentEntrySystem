package DialogFragments;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.zybooks.wgu.R;

import Assessments.AssessmentChoose;

public class DialogFragment_Update_Assessment extends DialogFragment {

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {

        int draw = R.drawable.baseline_emoji_people_24;

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Updated");
        builder.setIcon(draw);
        builder.setMessage("This has been updated. Thank you.");
        builder.setPositiveButton("OK", null);
        builder.setNegativeButton("Go to Assessments", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent send = new Intent(getContext(), AssessmentChoose.class);
                startActivity(send);
            }
        });
        return builder.create();

    }
}
