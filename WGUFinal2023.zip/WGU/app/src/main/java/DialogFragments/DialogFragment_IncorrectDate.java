package DialogFragments;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;

import androidx.fragment.app.DialogFragment;

import com.zybooks.wgu.R;

public class DialogFragment_IncorrectDate extends DialogFragment {


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        int draw = R.drawable.baseline_emoji_people_24;

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Incorrect Date");
        builder.setIcon(draw);
        builder.setMessage("Start Date cannot be same, or have same month or be after end date!");
        builder.setPositiveButton("Thank You", null);
        return builder.create();
    }
}
